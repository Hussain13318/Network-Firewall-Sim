#include <iostream>      // Standard input/output operations
#include <iomanip>       // For formatting output
#include <pcap.h>        // Packet capture library
#include <ctime>         // Time manipulation utilities
#include <ws2tcpip.h>    // IP and network functions
#include <fstream>       // File handling for logs
#include <unordered_set> // Efficient IP storage container
#include <sstream>       // String stream utilities
#include <limits>        // Numeric limits and boundaries
using namespace std;

// For counting total packets
int count = 0;

// Global Count Variables
int icmpCount, tcpCount, udpCount, otherCount, blockedPack = 0;

// Sets to store blocked IPs and Ports
unordered_set<string> blockedIPs;
unordered_set<string> blockedPorts;

// Structure for Ethernet Header
struct EthernetHeader
{
    u_char dest[6]; // Destination MAC address
    u_char src[6];  // Source MAC address
    u_short type;   // EtherType
};

// Structure of IPv4 Header
struct IPv4Header
{
    u_char ihl : 4;      // Internet Header Length
    u_char version : 4;  // IP version
    u_char tos;          // Type of service
    u_short length;      // Total length
    u_short id;          // Identification
    u_short offset;      // Fragment offset
    u_char ttl;          // Time to live
    u_char protocol;     // Protocol (TCP, UDP, etc.)
    struct in_addr src;  // Source IP address
    struct in_addr dest; // Destination IP address
};

// Packet handler function
void packetHandler(u_char *userData, const struct pcap_pkthdr *header, const u_char *packet);

// Function to load blocked IPs and blocked Ports from file
void loadBlockedIPs(const string &filename);
void loadBlockedPorts(const string &filename);

// Function to add a new IP and new Port to the blocked list
void addBlockedIP(const string &filename);
void addBlockedPorts(const string &filename);

// Function to remove an IP and port from the blocked list
void removeBlockedIP(const string &filename);
void removeBlockedPorts(const string &filename);

// Function to update the blocked IPs and blocked Port file
void updateBlockedIPsFile(const string &filename);
void updateBlockedPortsFile(const string &filename);

// Defining colors for formatting output
#define RED "\033[31m"
#define CYAN "\033[36m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
#define RESET "\033[0m"

int main()
{
    // Load blocked IPs and Portsfrom the file
    loadBlockedIPs("blocked_ips.txt");
    loadBlockedPorts("blocked_ports.txt");

    // Ascii Art
    cout << RED;
    cout << "  ______  _                             _  _    _____  _                    _         _    _               \n";
    cout << " |  ____|(_)                           | || |  / ____|(_)                  | |       | |  (_)              \n";
    cout << " | |__    _  _ __  ___ __      __ __ _ | || | | (___   _  _ __ ___   _   _ | |  __ _ | |_  _   ___   _ __  \n";
    cout << " |  __|  | || '__|/ _ \\\\ \\ /\\ / // _` || || |  \\___ \\ | || '_ ` _ \\ | | | || | / _` || __|| | / _ \\ | '_ \\ \n";
    cout << " | |     | || |  |  __/ \\ V  V /| (_| || || |  ____) || || | | | | || |_| || || (_| || |_ | || (_) || | | |\n";
    cout << " |_|     |_||_|   \\___|  \\_/\\_/  \\__,_||_||_| |_____/ |_||_| |_| |_| \\__,_||_| \\__,_| \\__||_| \\___/ |_| |_|\n";
    cout << "                                                                                                           \n";
    cout << RESET;

    // For user choice
    int menuChoice;
    do
    {
        cout << CYAN;
        cout << "\n========================== MENU ==========================" << endl;
        cout << "1. Start Packet Capture" << endl;
        cout << "2. Configure Rules" << endl;
        cout << "3. Exit" << endl;
        cout << "=========================================================" << endl;
        cout << "Enter your choice: ";
        cin >> menuChoice;
        cout << RESET;

        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (menuChoice < 1 || menuChoice > 3)
        {
            cout << RED << "Invalid choice! Please enter a number between 1 and 3." << RESET << endl;
            continue;
        }

        if (menuChoice == 2)
        {
            int configChoice;
            do
            {
                cout << CYAN;
                cout << "\n==================== CONFIGURE RULES ====================" << endl;
                cout << "1. Add IP to Blocked List" << endl;
                cout << "2. Remove IP from Blocked List" << endl;
                cout << "3. Add Port to Blocked List" << endl;
                cout << "4. Remove Port from Blocked List" << endl;
                cout << "5. View Blocked Ips" << endl;
                cout << "6. View Blocked Ports" << endl;
                cout << "7. Return to Main Menu" << endl;
                cout << "=========================================================" << endl;
                cout << "Enter your choice: ";
                cin >> configChoice;
                cout << RESET;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');

                if (configChoice < 1 || configChoice > 7)
                {
                    cout << RED << "Invalid choice! Please enter a number between 1 and 5." << RESET << endl;
                    continue;
                }

                if (configChoice == 1)
                {
                    addBlockedIP("blocked_ips.txt");
                }
                else if (configChoice == 2)
                {
                    removeBlockedIP("blocked_ips.txt");
                }
                else if (configChoice == 3)
                {
                    addBlockedPorts("blocked_ports.txt");
                }
                else if (configChoice == 4)
                {
                    removeBlockedPorts("blocked_ports.txt");
                }
                else if (configChoice == 5)
                {
                    ifstream display("blocked_ips.txt");
                    string bips;
                    cout << YELLOW << "BLOCKED IPS" << RESET << endl;
                    while (getline(display, bips))
                    {
                        cout << RED << bips << RESET << endl;
                    }
                }
                else if (configChoice == 6)
                {
                    ifstream display("blocked_ports.txt");
                    string bports;
                    cout << YELLOW << "BLOCKED PORTS" << RESET << endl;
                    while (getline(display, bports))
                    {
                        cout << RED << bports << RESET << endl;
                    }
                }

            } while (configChoice != 7);
        }
        else if (menuChoice == 1)
        {
            char errbuf[PCAP_ERRBUF_SIZE]; // Error buffer
            pcap_if_t *allDevices;         // List of devices
            pcap_if_t *device;             // Selected device

            // Find all network devices
            if (pcap_findalldevs(&allDevices, errbuf) == -1)
            {
                cerr << "Error finding devices: " << errbuf << endl;
                return 1;
            }

            // List all devices
            int deviceCount = 0;
            cout << BLUE;
            cout << "\n=======================================================" << endl;
            cout << "                  AVAILABLE NETWORK DEVICES            " << endl;
            cout << "=======================================================" << endl;
            cout << RESET;

            for (device = allDevices; device; device = device->next)
            {
                cout << left << setw(3) << ++deviceCount << ". "
                     << (device->description ? device->description : "No Description Available") << endl;
            }

            if (deviceCount == 0)
            {
                cerr << "No devices found!" << endl;
                pcap_freealldevs(allDevices);
                return 1;
            }
            int selectedDevice;
            while (true)
            {
                cout << BLUE << "=======================================================" << RESET << endl;
                cout << "Select a device (1-" << deviceCount << "): ";
                cin >> selectedDevice;
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');

                if (selectedDevice < 1 || selectedDevice > deviceCount)
                {
                    cerr << RED << "Invalid device selection! Please select a valid device." << RESET << endl;
                }
                else
                {
                    break;
                }
            }

            // Find the selected device
            device = allDevices;
            for (int i = 1; i < selectedDevice; i++)
            {
                device = device->next;
            }

            cout << "\nUsing device: " << (device->description ? device->description : "No Description Available") << endl;

            // Open the device for live capture
            pcap_t *handle = pcap_open_live(device->name, BUFSIZ, 1, 1000, errbuf);
            if (!handle)
            {
                cerr << "Failed to open device: " << errbuf << endl;
                pcap_freealldevs(allDevices);
                return 1;
            }

            int timeRun;
            cout << BLUE;
            cout << "\n=========================================================" << endl;
            cout << "                 PACKET CAPTURE SETTINGS               " << endl;
            cout << "=========================================================" << endl;
            cout << RESET;

            // Check if input for time is valid
            while (true)
            {
                cout << "Enter the time (in seconds) you want to capture traffic for: ";
                cin >> timeRun;

                // Check i finput is an integer
                if (cin.fail())
                {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << RED << "Invalid input! Please enter a positive integer." << RESET << endl;
                    continue;
                }

                if (timeRun > 0)
                {
                    break;
                }
                else
                {
                    cout << RED << "Time must be a positive integer greater than zero!" << RESET << endl;
                }
            }

            cout << BLUE;
            cout << "\n=======================================================" << endl;
            cout << "Capturing packets for " << timeRun << " seconds..." << endl;
            cout << "=======================================================\n";
            cout << RESET;

            // Capture packets for the specified time by the user
            time_t startTime = time(nullptr);
            while (true)
            {
                pcap_dispatch(handle, 0, packetHandler, nullptr);

                // Check elapsed time
                if (time(nullptr) - startTime >= timeRun)
                {
                    break;
                }
            }

            cout << YELLOW;
            cout << "\n=========================================================" << endl;
            cout << "                 PACKET CAPTURE Report                   " << endl;
            cout << "=========================================================" << endl;
            cout << "Finished capturing packets." << endl;
            cout << "Total IP packets captured: " << count << endl;
            cout << "ICMP packets: " << icmpCount << endl;
            cout << "TCP packets: " << tcpCount << endl;
            cout << "UDP packets: " << udpCount << endl;
            cout << "Other packets: " << otherCount << endl;
            cout << "Blocked Packets: " << blockedPack << endl;
            cout << RESET;

            pcap_close(handle);
            pcap_freealldevs(allDevices);
        }

    } while (menuChoice != 3);

    cout << GREEN << "Thank you for using the Firewall Simulation, Bye!" << RESET << endl;
    return 0;
}

// Function to load blocked IPs from a file
void loadBlockedIPs(const string &filename)
{
    ifstream infile(filename);
    string ip;
    while (getline(infile, ip))
    {
        blockedIPs.insert(ip); // Add each blocked IP to the unordered set
    }
    infile.close();
}

// Function to add a new IP to the blocked list
void addBlockedIP(const string &filename)
{
    cout << CYAN << "Enter the IP address to block: " << RESET;
    string newIP;
    cin >> newIP;

    if (blockedIPs.find(newIP) == blockedIPs.end())
    {
        blockedIPs.insert(newIP);

        ofstream outfile(filename, ios::app);
        outfile << newIP << endl;
        outfile.close();

        cout << GREEN << "IP address " << newIP << " added to the blocked list." << RESET << endl;
    }
    else
    {
        cout << RED << "IP address " << newIP << " is already in the blocked list." << RESET << endl;
    }
}

// Function to remove an IP from the blocked list
void removeBlockedIP(const string &filename)
{
    cout << CYAN << "Enter the IP address to unblock: " << RESET;
    string ipToRemove;
    cin >> ipToRemove;

    if (blockedIPs.find(ipToRemove) != blockedIPs.end())
    {
        blockedIPs.erase(ipToRemove);
        updateBlockedIPsFile(filename); // Update the file after removal
        cout << GREEN << "IP address " << ipToRemove << " removed from the blocked list." << RESET << endl;
    }
    else
    {
        cout << YELLOW << "IP address " << ipToRemove << " is not in the blocked list." << RESET << endl;
    }
}

// Function to update the blocked IPs file after removal
void updateBlockedIPsFile(const string &filename)
{
    ofstream outfile(filename);
    for (const auto &ip : blockedIPs)
    {
        outfile << ip << endl;
    }
    outfile.close();
}

// --------------------------------------------
// --------------------------------------------

// Function to load blocked Ports from a file
void loadBlockedPorts(const string &filename)
{
    ifstream infile(filename);
    string port;
    while (getline(infile, port))
    {
        blockedPorts.insert(port);
    }
    infile.close();
}

// Function to add a new port to the blocked list
void addBlockedPorts(const string &filename)
{
    cout << "Enter the Port to block: ";
    string port;
    cin >> port;

    if (blockedPorts.find(port) == blockedPorts.end())
    {
        blockedPorts.insert(port);

        ofstream outfile(filename, ios::app);
        outfile << port << endl;
        outfile.close();

        cout << GREEN << "Port " << port << " added to the blocked list." << RESET << endl;
    }
    else
    {
        cout << RED << "Port " << port << " is already in the blocked list." << RESET << endl;
    }
}

// Function to remove a port from the blocked list
void removeBlockedPorts(const string &filename)
{
    cout << "Enter the Port to unblock: ";
    string portToRemove;
    cin >> portToRemove;

    if (blockedPorts.find(portToRemove) != blockedPorts.end())
    {
        blockedPorts.erase(portToRemove);
        updateBlockedPortsFile(filename); // Update the file after removal
        cout << GREEN << "Port " << portToRemove << " removed from the blocked list." << RESET << endl;
    }
    else
    {
        cout << GREEN << "Port " << portToRemove << " is not in the blocked list." << RESET << endl;
    }
}

// Function to update the blocked Ports file after removal
void updateBlockedPortsFile(const string &filename)
{
    ofstream outfile(filename);
    for (const auto &port : blockedPorts)
    {
        outfile << port << endl;
    }
    outfile.close();
}

// --------------------------------------------
// --------------------------------------------

// Packet handler function
void packetHandler(u_char *userData, const struct pcap_pkthdr *header, const u_char *packet)
{
    // Extract the Ethernet header
    EthernetHeader *ethHeader = (EthernetHeader *)(packet);

    // Check if the packet is an IP packet
    if (ntohs(ethHeader->type) != 0x0800)
    {
        return;
    }

    // Extract the IP header
    IPv4Header *ipHeader = (IPv4Header *)(packet + sizeof(EthernetHeader));

    // Convert source and destination IP addresses to strings
    char srcIP[16]; // or INET_ADDRSTRLEN
    char destIP[16];
    strncpy(srcIP, inet_ntoa(ipHeader->src), 16);
    strncpy(destIP, inet_ntoa(ipHeader->dest), 16);

    // Check if the source IP is in the blocked list
    string srcIPString(srcIP);
    bool isIpBlocked = (blockedIPs.find(srcIPString) != blockedIPs.end());

    // Variables to store the protocol name
    string protocol_name = "";
    uint16_t srcPort = 0;
    uint16_t destPort = 0;

    // Pointer to transport layer (TCP/UDP header)
    const u_char *transportHeader = packet + sizeof(EthernetHeader) + (ipHeader->ihl * 4);

    switch (static_cast<int>(ipHeader->protocol))
    {
    case 1:
        protocol_name = "ICMP";
        icmpCount++;
        break;
    case 6:
        protocol_name = "TCP";
        srcPort = ntohs(*(uint16_t *)transportHeader);        // Source port
        destPort = ntohs(*(uint16_t *)(transportHeader + 2)); // Destination port
        tcpCount++;
        break;
    case 17:
        protocol_name = "UDP";
        srcPort = ntohs(*(uint16_t *)transportHeader);        // Source port
        destPort = ntohs(*(uint16_t *)(transportHeader + 2)); // Destination port
        udpCount++;
        break;
    default:
        protocol_name = "Other";
        otherCount++;
    }

    // convert port to string for comparison
    string srcPortString(to_string(srcPort));
    bool isPortBlocked = (blockedPorts.find(srcPortString) != blockedPorts.end());

    // Open a file in append mode to store the output
    ofstream storefile("log.txt", ios::app);

    // Output message to store in the file
    stringstream output;
    output << "Packet captured: Length = " << header->len << " bytes" << endl;
    output << "Source IP: " << left << setw(15) << srcIP << " Destination IP: " << left << setw(15) << destIP << " | Protocol: " << protocol_name << " | SrcPort: " << left << setw(5) << srcPort << " | DestPort: " << left << setw(5) << destPort;

    // IF the port or ip found in block list the display this after the packet
    if (isIpBlocked || isPortBlocked)
    {
        output << " | Blocked packet" << endl;
        blockedPack++;
    }
    else
    {
        output << endl;
    }

    // Write the output to the file
    storefile << output.str();

    // Display the output
    cout << output.str();

    // Close the file
    storefile.close();

    cout << endl;
    count++;
}
